<?php
// Text
$_['text_title']      = '<img style="width: 90px;" src="catalog/view/theme/default/image/intend-logo.png" alt="Intend Оплата" title="Intend Оплата" />';
$_['text_form_title'] = 'Допольнительная информация';

$_['entry_phone_number']             = 'Номер телефона';
$_['entry_phone_number_palceholder'] = 'Пожалуйста, введите ваш номер телефона';

$_['entry_email']             = 'Email';
$_['entry_email_placeholder'] = 'Пожалуйста введите ваш email';

$_['entry_duration'] = 'Месяц';
$_['button_confirm'] = 'Оплатить с помощью Intend';
