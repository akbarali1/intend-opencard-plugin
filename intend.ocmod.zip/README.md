# intend-opencard-plugin

Tez orada o'rnatish bo'yicha qo'llanma qo'shiladi.
# opencart_plagin_intend_v1
